import sqlite3
import random
import asyncio
from telegram import (
    Update, InlineKeyboardButton, InlineKeyboardMarkup,
    BotCommand, BotCommandScopeChat
)
from telegram.ext import (
    ApplicationBuilder, CommandHandler,
    ContextTypes, CallbackQueryHandler
)

TOKEN = "8696493679:AAGqomcu26PD4x6ol02tFrO4610mFwX04QQ"
OWNER_ID = 8071763442

# ---------------- BANCO ---------------- #

conn = sqlite3.connect("bot.db", check_same_thread=False)
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY,
    saldo INTEGER DEFAULT 1000,
    banco INTEGER DEFAULT 0,
    chance INTEGER DEFAULT 50
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS config (
    id INTEGER PRIMARY KEY DEFAULT 1,
    bonus INTEGER DEFAULT 500,
    juros INTEGER DEFAULT 5,
    chance_global INTEGER DEFAULT 50,
    cofre INTEGER DEFAULT 0
)
""")

cursor.execute("INSERT OR IGNORE INTO config (id) VALUES (1)")
conn.commit()

def registrar(user_id):
    cursor.execute("INSERT OR IGNORE INTO users (id) VALUES (?)", (user_id,))
    conn.commit()

def get_saldo(user_id):
    cursor.execute("SELECT saldo FROM users WHERE id=?", (user_id,))
    return cursor.fetchone()[0]

def alterar_saldo(user_id, valor):
    cursor.execute("UPDATE users SET saldo = saldo + ? WHERE id=?", (valor, user_id))
    conn.commit()

def get_banco(user_id):
    cursor.execute("SELECT banco FROM users WHERE id=?", (user_id,))
    return cursor.fetchone()[0]

def alterar_banco(user_id, valor):
    cursor.execute("UPDATE users SET banco = banco + ? WHERE id=?", (valor, user_id))
    conn.commit()

def get_config(campo):
    cursor.execute(f"SELECT {campo} FROM config WHERE id=1")
    return cursor.fetchone()[0]

def set_config(campo, valor):
    cursor.execute(f"UPDATE config SET {campo}=? WHERE id=1", (valor,))
    conn.commit()

# ---------------- MENU ---------------- #

async def configurar_comandos(app):

    membros = [
        BotCommand("saldo","Saldo"),
        BotCommand("banco","Banco"),
        BotCommand("depositar","Depositar"),
        BotCommand("sacar","Sacar"),
        BotCommand("bonus","Bonus"),
        BotCommand("doar","Doar"),
        BotCommand("rank","Ranking"),
        BotCommand("cassino","Cassino"),
        BotCommand("crash","Crash"),
        BotCommand("tigrinho","Tigrinho"),
    ]

    dono = membros + [
        BotCommand("addsaldo","Add saldo"),
        BotCommand("removersaldo","Remover saldo"),
        BotCommand("setchance","Set chance global"),
        BotCommand("setchanceuser","Set chance user"),
        BotCommand("setbonus","Set bonus"),
        BotCommand("setjuros","Set juros"),
        BotCommand("cofre","Ver cofre"),
        BotCommand("drop","Criar drop"),
    ]

    await app.bot.set_my_commands(membros)
    await app.bot.set_my_commands(
        dono,
        scope=BotCommandScopeChat(chat_id=OWNER_ID)
    )

# ---------------- COMANDOS MEMBROS ---------------- #

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    registrar(update.effective_user.id)
    await update.message.reply_text("🎰 Cassino Bot Online!")

async def saldo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    registrar(update.effective_user.id)
    await update.message.reply_text(f"💰 {get_saldo(update.effective_user.id)}")

async def banco(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(f"🏦 {get_banco(update.effective_user.id)}")

async def depositar(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user.id
    valor = int(context.args[0])
    if get_saldo(user) >= valor:
        alterar_saldo(user, -valor)
        alterar_banco(user, valor)
        await update.message.reply_text("✅ Depositado")
    else:
        await update.message.reply_text("❌ Saldo insuficiente")

async def sacar(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user.id
    valor = int(context.args[0])
    if get_banco(user) >= valor:
        alterar_banco(user, -valor)
        alterar_saldo(user, valor)
        await update.message.reply_text("✅ Sacado")
    else:
        await update.message.reply_text("❌ Banco insuficiente")

async def bonus(update: Update, context: ContextTypes.DEFAULT_TYPE):
    alterar_saldo(update.effective_user.id, get_config("bonus"))
    await update.message.reply_text("🎁 Bonus recebido!")

async def cassino(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user.id
    valor = int(context.args[0])

    if get_saldo(user) < valor:
        await update.message.reply_text("❌ Saldo insuficiente")
        return

    alterar_saldo(user, -valor)

    chance = get_config("chance_global")
    if random.randint(1,100) <= chance:
        ganho = valor * 2
        alterar_saldo(user, ganho)
        set_config("cofre", get_config("cofre") - valor)
        await update.message.reply_text(f"🎰 GANHOU {ganho}")
    else:
        set_config("cofre", get_config("cofre") + valor)
        await update.message.reply_text("🎰 Perdeu")

# ---------------- CRASH ---------------- #

crash_data = {}

async def crash(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user.id
    valor = int(context.args[0])

    if get_saldo(user) < valor:
        await update.message.reply_text("❌ Saldo insuficiente")
        return

    alterar_saldo(user, -valor)
    crash_data[user] = {"ativo": True, "multi": 1.0}

    keyboard = [[InlineKeyboardButton("🛑 PARAR", callback_data="parar")]]
    msg = await update.message.reply_text("💣 Crash iniciado!", reply_markup=InlineKeyboardMarkup(keyboard))

    while crash_data[user]["ativo"]:
        await asyncio.sleep(0.5)
        crash_data[user]["multi"] += 0.3

        if random.random() < 0.1:
            crash_data[user]["ativo"] = False
            await msg.edit_text("💥 Explodiu!")
            return

        await msg.edit_text(f"🚀 {round(crash_data[user]['multi'],2)}x", reply_markup=InlineKeyboardMarkup(keyboard))

async def parar(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user = query.from_user.id

    if user in crash_data and crash_data[user]["ativo"]:
        crash_data[user]["ativo"] = False
        ganho = int(crash_data[user]["multi"] * 100)
        alterar_saldo(user, ganho)
        await query.edit_message_text(f"💰 Ganhou {ganho}")

# ---------------- ADMIN ---------------- #

async def addsaldo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != OWNER_ID:
        return
    user = update.message.reply_to_message.from_user.id
    valor = int(context.args[0])
    alterar_saldo(user, valor)
    await update.message.reply_text("✅ Adicionado")

async def removersaldo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != OWNER_ID:
        return
    user = update.message.reply_to_message.from_user.id
    valor = int(context.args[0])
    alterar_saldo(user, -valor)
    await update.message.reply_text("✅ Removido")

async def setchance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != OWNER_ID:
        return
    set_config("chance_global", int(context.args[0]))
    await update.message.reply_text("✅ Chance global alterada")

async def setbonus(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != OWNER_ID:
        return
    set_config("bonus", int(context.args[0]))
    await update.message.reply_text("✅ Bonus alterado")

async def setjuros(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != OWNER_ID:
        return
    set_config("juros", int(context.args[0]))
    await update.message.reply_text("✅ Juros alterado")

async def cofre(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != OWNER_ID:
        return
    await update.message.reply_text(f"💎 Cofre: {get_config('cofre')}")

# ---------------- MAIN ---------------- #

async def main():
    app = ApplicationBuilder().token(TOKEN).build()

    await configurar_comandos(app)

    comandos = [
        "start","saldo","banco","depositar","sacar","bonus",
        "cassino","crash","addsaldo","removersaldo",
        "setchance","setbonus","setjuros","cofre"
    ]

    for cmd in comandos:
        app.add_handler(CommandHandler(cmd, globals()[cmd]))

    app.add_handler(CallbackQueryHandler(parar, pattern="parar"))

    print("Bot ON 🚀")
    app.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())